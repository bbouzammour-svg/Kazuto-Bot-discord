/**
 * Discord.js v14 Bot — Dynamic Prefix (&) Command Handler
 * Includes: Express Keep-Alive, Antispam, Antinuke, Tickets, Temp Voice, and 20+ Commands
 */

require('dotenv').config();

const path = require('path');
const fs = require('fs');
const express = require('express');

const {
  Client,
  GatewayIntentBits,
  Partials,
  PermissionsBitField,
  ChannelType,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
} = require('discord.js');

// ============================================================
// KEEP-ALIVE WEB SERVER (PREVENTS FREE HOSTS FROM SHUTTING OFF)
// ============================================================
const app = express();
app.get('/', (req, res) => res.send('Bot is active and running!'));
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Web server listening on port ${PORT} to keep bot awake.`));

// ============================================================
// CONFIGURATION
// ============================================================
const BOT_TOKEN = process.env.DISCORD_BOT_TOKEN || process.env.DISCORD_TOKEN || 'YOUR_BOT_TOKEN_HERE';
const PREFIX = '&';

// --- Missing Command Variables Fix ---
const CLEAR_COMMAND = 'clear';
const HELP_COMMAND = 'help';
const PING_COMMAND = 'ping';
const AVATAR_COMMAND = 'avatar';
const USERINFO_COMMAND = 'userinfo';
const SERVERINFO_COMMAND = 'serverinfo';
const SLOWMODE_COMMAND = 'slowmode';
const REMOVE_ALL_ROLES_COMMAND = 'removeallroles';
const REMOVE_MEMBERS_ROLES_COMMAND = 'removemembersroles';
const ALL_MEMBERS_COMMAND = 'allmembers';

// --- Ticket Config ---
const TICKET_SETUP_COMMAND = 'ticketcreatesetup';
const TICKET_SETUP_CHANNEL_NAME = '🎫・𝘵𝘪𝘤𝘬𝘦𝘵';
const TICKET_MANAGER_ROLE_NAME = '✿ 𝘛𝘪𝘤𝘬𝘦𝘵 𝘔𝘢𝘯𝘢𝘨𝘦𝘳';
const CREATE_TICKET_BUTTON_CUSTOM_ID = 'create_ticket_btn';

const TICKET_THUMBNAIL_URL = 'https://i.pinimg.com/originals/d7/a4/6a/d7a46a0f26c03d2eb10c620922eca84c.gif';
const TICKET_IMAGE_URL = 'https://i.pinimg.com/originals/22/61/c4/2261c4c27623e203d3b8729fd8d667ba.gif';
const TICKET_BANNER_URL = 'https://i.pinimg.com/originals/19/59/b4/1959b45b2e1f508b7ed387a236e6d117.gif';
const TICKET_EMOJI_NAME = 'ticket_icon';
const CLOSE_TICKET_EMOJI = '1537987795296067625';
const CLAIM_TICKET_EMOJI = '1537988150121463828';

const ticketCreateCooldowns = new Map();
const ticketCloseCooldowns = new Map();

// --- Join-to-Create Voice Config ---
const AUTOSETUP_ONETAP_COMMAND = 'autosetuponetap';
const ONE_TAP_CATEGORY_NAME = '➕ One Tap';
const JOIN_TO_CREATE_CHANNEL_NAME = '➕ One Tap';
const VC_COLOR = '#00FFFF';
const VC_BANNER_URL = 'https://i.pinimg.com/originals/3d/a9/a5/3da9a53ad9dedebe3ba316a6703b8d83.gif';

const TEMP_VOICE_EMOJIS = {
  lock: '1537613455605891132', unlock: '1537810263989035049', hide: '1537810585733963857',
  unhide: '1537810768622395512', crown: '1537811057651749005', pen: '1537811305300365413',
  limit: '1537811504567554059', plus: '1537815728034553887', minus: '1537815885597900862', info: '1537816142243041351',
};

// --- Command Settings ---
const CLEAR_DEFAULT_AMOUNT = 25;
const CLEAR_MAX_AMOUNT = 100;
const TEMP_REPLY_DELETE_MS = 6000;
const MAX_SLOWMODE_SECONDS = 21600;

// --- Global State Stores ---
const tempChannels = new Map();
const generatorChannels = new Map();
const ticketData = new Map();

// --- Antinuke & Antispam State ---
const antinukeSettings = new Map();
const whitelistedUsers = new Set();
const spamCache = new Map();

// --- Custom Emojis ---
// FIXED: Now uses the animated spinning heart format
const DOT_EMOJI = '<a:001_hrtspin:1332185935072198687>';

function resolveAssetPath(fileName) {
  const rootPath = path.join(process.cwd(), 'assets', fileName);
  if (fs.existsSync(rootPath)) return rootPath;
  const currentPath = path.join(__dirname, fileName);
  if (fs.existsSync(currentPath)) return currentPath;
  return null;
}

// ============================================================
// CLIENT SETUP
// ============================================================
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildModeration,
  ],
  partials: [Partials.Channel],
});

client.once('clientReady', () => console.log(`Logged in as ${client.user.tag}`));

// ============================================================
// HELPER FUNCTIONS
// ============================================================
async function findOrCreateTextChannel(guild, name, reason) {
  let channel = guild.channels.cache.find((c) => c.type === ChannelType.GuildText && (c.name === name || c.name.includes(name)));
  if (!channel) channel = await guild.channels.create({ name, type: ChannelType.GuildText, reason });
  return channel;
}

async function findOrCreateCategory(guild, name, reason) {
  let category = guild.channels.cache.find((c) => c.type === ChannelType.GuildCategory && c.name === name);
  if (!category) category = await guild.channels.create({ name, type: ChannelType.GuildCategory, reason });
  return category;
}

async function findOrCreateRole(guild, name, options, reason) {
  let role = guild.roles.cache.find((r) => r.name === name);
  if (!role) role = await guild.roles.create({ name, reason, ...options });
  return role;
}

async function findOrCreateCustomEmoji(guild, name, assetFileName) {
  const existing = guild.emojis.cache.find((e) => e.name === name);
  if (existing) return existing;
  const assetPath = resolveAssetPath(assetFileName);
  if (!assetPath) return null;
  try {
    return await guild.emojis.create({ attachment: assetPath, name, reason: `Auto-created emoji (${name}).` });
  } catch (err) {
    return null;
  }
}

async function resolveMember(guild, input) {
  if (!input) return null;
  const mentionMatch = input.match(/^<@!?(\d+)>$/);
  const id = mentionMatch ? mentionMatch[1] : input;
  return guild.members.fetch(id).catch(() => null);
}

function sendTempReply(channel, content, ms = TEMP_REPLY_DELETE_MS) {
  channel.send(content).then((sent) => setTimeout(() => sent.delete().catch(() => {}), ms)).catch(() => {});
}

function clampAmount(rawValue, fallback, max) {
  const parsed = parseInt(rawValue, 10);
  if (!Number.isInteger(parsed) || parsed <= 0) return fallback;
  return Math.min(parsed, max);
}

// ============================================================
// TEMP VOICE EMBEDS & BUTTONS
// ============================================================
function createControlPanelEmbed(owner) {
  return new EmbedBuilder()
    .setColor(VC_COLOR)
    .setTitle('Kazuto Temp Voice')
    .setDescription(`Welcome ${owner ? `<@${owner.id}>` : 'there'}!\nUse the interactive buttons below or prefix commands (\`&\`) to manage your channel.`)
    .setImage(VC_BANNER_URL)
    .setFooter({ text: `Owner: ${owner ? owner.user.tag : 'None'}`, iconURL: owner ? owner.user.displayAvatarURL() : null });
}

function createControlButtons() {
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tv_lock').setEmoji(TEMP_VOICE_EMOJIS.lock).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('tv_unlock').setEmoji(TEMP_VOICE_EMOJIS.unlock).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('tv_hide').setEmoji(TEMP_VOICE_EMOJIS.hide).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('tv_unhide').setEmoji(TEMP_VOICE_EMOJIS.unhide).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('tv_claim').setEmoji(TEMP_VOICE_EMOJIS.crown).setStyle(ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tv_rename').setEmoji(TEMP_VOICE_EMOJIS.pen).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('tv_limit').setEmoji(TEMP_VOICE_EMOJIS.limit).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('tv_allow').setEmoji(TEMP_VOICE_EMOJIS.plus).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('tv_deny').setEmoji(TEMP_VOICE_EMOJIS.minus).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('tv_info').setEmoji(TEMP_VOICE_EMOJIS.info).setStyle(ButtonStyle.Secondary)
  );

  return [row1, row2];
}

// ============================================================
// DROPDOWN HELP BUILDER
// ============================================================
function getHelpMainEmbed() {
  return new EmbedBuilder()
    .setColor('#2b2d31')
    .setAuthor({ name: '👋 Hello, I\'m Kazuto Kirigaya - 桐ヶ谷和人' })
    .setDescription('Welcome! Thanks for using my bot. Use **&help** to explore all available commands. Choose a category from the dropdown menu below to view every command.\n\n**• Prefix for this server:** `&`\n**• Type** `&help` **to view all commands.**\n**• Select a category below to display its commands.**\n**• Need help? Join our [Support Server](https://discord.gg/V9AUP8Mb2t).**')
    .setThumbnail('https://i.pinimg.com/originals/20/ff/e4/20ffe419796909feca129d6ab0e846ee.gif')
    .setImage('https://cdn.discordapp.com/attachments/1532146532567220397/1537974779548667984/Reblog_by_siix-eyes_1_image.gif?ex=6a81a6e1&is=6a805561&hm=ab1e874938ffbaf6920f711ba657b0271236077222ee6933e51a92beb5daace5&');
}

function getHelpDropdown(requesterId) {
  return new StringSelectMenuBuilder()
    .setCustomId(`help_menu_${requesterId}`)
    .setPlaceholder('↘ Select a module to see')
    .addOptions(
      { label: 'Home', description: 'Return to the main help page', value: 'help_home', emoji: { id: '1538200496517419108' } },
      { label: 'General', description: 'Server utilities, lists, avatar & more', value: 'help_general', emoji: { id: '1538200713216401589' } },
      { label: 'Information', description: 'Bot info, server stats & user details', value: 'help_info', emoji: { id: '1538200940514119721' } },
      { label: 'Moderation', description: 'Ban, kick, mute, lock & more', value: 'help_mod', emoji: { id: '1538201260090720258' } },
      { label: 'Antinuke', description: 'Protect your server from raids & nukes', value: 'help_antinuke', emoji: { id: '1538201603818127370' } }
    );
}

function buildHelpMenu(requesterId) {
  const row = new ActionRowBuilder().addComponents(getHelpDropdown(requesterId));
  return { embeds: [getHelpMainEmbed()], components: [row] };
}

// ============================================================
// VOICE STATE UPDATE (JOIN TO CREATE)
// ============================================================
client.on('voiceStateUpdate', async (oldState, newState) => {
  const guild = newState.guild;
  const isGenerator = newState.channel && (generatorChannels.get(guild.id)?.generatorChannelId === newState.channelId || newState.channel.name === JOIN_TO_CREATE_CHANNEL_NAME);

  if (isGenerator) {
    const member = newState.member;
    const category = newState.channel.parent;
    try {
      const voiceChannel = await guild.channels.create({
        name: `🔊 ${member.displayName}'s Room`,
        type: ChannelType.GuildVoice,
        parent: category ? category.id : null,
        permissionOverwrites: [
          { id: guild.roles.everyone.id, allow: [PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.ViewChannel] },
          { id: member.id, allow: [PermissionsBitField.Flags.ManageChannels, PermissionsBitField.Flags.MuteMembers, PermissionsBitField.Flags.DeafenMembers] },
        ],
      });
      tempChannels.set(voiceChannel.id, { ownerId: member.id });
      await newState.setChannel(voiceChannel);
      await voiceChannel.send({ embeds: [createControlPanelEmbed(member)], components: createControlButtons() }).catch(() => {});
    } catch (err) { console.error(err); }
  }

  if (oldState.channelId && oldState.channelId !== newState.channelId) {
    const channel = oldState.channel;
    if (channel && tempChannels.has(channel.id) && channel.members.size === 0) {
      tempChannels.delete(channel.id);
      await channel.delete().catch(() => {});
    }
  }
});

function buildTicketSetupMessage(ticketEmoji) {
  const embed = new EmbedBuilder()
    .setTitle('░▒▓█ • TICKETS 🔔 █▓▒░')
    .setDescription('. ⋅ ˚ ✦ ───────────── ✦ ˚ ⋅ .\n    ▼   Here   ▼     ▼   Here  ▼\n\n▪ No joke tickets\n▪ Be extremely patient\n▪ State issue immediately\n▪ No pinging staff\n▪ One ticket max\n\n')
    .setColor(16771584)
    .setImage(TICKET_IMAGE_URL)
    .setThumbnail(TICKET_THUMBNAIL_URL)
    .setFooter({ text: 'Developed By Vipex All rights reserved' });
  const button = new ButtonBuilder().setCustomId(CREATE_TICKET_BUTTON_CUSTOM_ID).setLabel('Create Ticket').setEmoji(ticketEmoji ? { id: ticketEmoji.id, name: ticketEmoji.name } : '🎫').setStyle(ButtonStyle.Primary);
  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(button)] };
}

// ============================================================
// MAIN MESSAGE HANDLER (COMMANDS & ANTISPAM)
// ============================================================
client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.guild) return;

  // --- ANTISPAM LOGIC ---
  if (antinukeSettings.get(`${message.guild.id}_antispam`) === true) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator) && !whitelistedUsers.has(message.author.id)) {
      const now = Date.now();
      if (!spamCache.has(message.author.id)) spamCache.set(message.author.id, []);
      
      let userMessages = spamCache.get(message.author.id);
      userMessages.push({ id: message.id, time: now });
      
      userMessages = userMessages.filter(msgData => now - msgData.time < 5000); // 5 seconds
      spamCache.set(message.author.id, userMessages);

      if (userMessages.length >= 6) {
        try {
          const messageIds = userMessages.map(m => m.id);
          await message.channel.bulkDelete(messageIds).catch(() => {});
          spamCache.delete(message.author.id);
          message.channel.send(`⚠️ <@${message.author.id}>, stop spamming! Messages deleted.`).then(m => setTimeout(() => m.delete().catch(()=>null), 4000));
        } catch (err) {}
      }
    }
  }

  if (!message.content.startsWith(PREFIX)) return;
  const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const commandName = args.shift()?.toLowerCase();

  try {
    // ------------------------------------------
    // TEMP VOICE TEXT COMMANDS
    // ------------------------------------------
    const voiceChannel = message.member?.voice?.channel;
    const isTempVoiceCommand = ['panel', 'lock', 'unlock', 'hide', 'unhide', 'claim', 'name', 'rename', 'limit'].includes(commandName);

    if (isTempVoiceCommand) {
      if (commandName === 'panel') {
        const ownerId = voiceChannel && tempChannels.has(voiceChannel.id) ? tempChannels.get(voiceChannel.id).ownerId : message.author.id;
        const ownerMember = await message.guild.members.fetch(ownerId).catch(() => message.member);
        return message.channel.send({ embeds: [createControlPanelEmbed(ownerMember)], components: createControlButtons() });
      }

      if (!voiceChannel || !tempChannels.has(voiceChannel.id)) return message.reply('❌ You must be in an active temp voice channel.');
      
      const channelData = tempChannels.get(voiceChannel.id);
      const isOwner = channelData.ownerId === message.author.id;

      if (commandName === 'claim') {
        if (!voiceChannel.members.has(channelData.ownerId)) {
          channelData.ownerId = message.author.id;
          return message.reply(`👑 <@${message.author.id}> is now the owner!`);
        }
        return message.reply('❌ Current owner is still inside the channel.');
      }
      if (!isOwner) return message.reply('🔒 Only the owner can run room commands.');

      switch (commandName) {
        case 'lock': await voiceChannel.permissionOverwrites.edit(message.guild.roles.everyone, { Connect: false }); return message.reply('🔒 Locked.');
        case 'unlock': await voiceChannel.permissionOverwrites.edit(message.guild.roles.everyone, { Connect: true }); return message.reply('🔓 Unlocked.');
        case 'hide': await voiceChannel.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: false }); return message.reply('🙈 Hidden.');
        case 'unhide': await voiceChannel.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: true }); return message.reply('👁️ Unhidden.');
        case 'name':
        case 'rename': await voiceChannel.setName(args.join(' ') || 'Temp Room'); return message.reply(`✏️ Renamed.`);
        case 'limit': await voiceChannel.setUserLimit(parseInt(args[0]) || 0); return message.reply(`👥 Limit updated.`);
      }
      return;
    }

    // ------------------------------------------
    // GENERAL COMMANDS
    // ------------------------------------------
    if (commandName === 'help') return message.reply(buildHelpMenu(message.author.id));
    if (commandName === 'say') {
      const sayMsg = args.join(' ');
      if (!sayMsg) return message.reply('❌ You need to provide a message!');
      await message.delete().catch(() => {});
      return message.channel.send(sayMsg);
    }
    if (commandName === '8ball') {
      const answers = ['It is certain.', 'Without a doubt.', 'Yes - definitely.', 'Most likely.', 'Outlook good.', 'Ask again later.', 'Cannot predict now.', 'Don\'t count on it.', 'My reply is no.', 'Very doubtful.'];
      if (!args[0]) return message.reply('🎱 Please ask a question.');
      return message.reply(`🎱 **8-Ball says:** ${answers[Math.floor(Math.random() * answers.length)]}`);
    }
    if (commandName === 'coinflip') {
      const result = Math.random() < 0.5 ? 'Heads' : 'Tails';
      return message.reply(`🪙 The coin landed on: **${result}**!`);
    }
    if (commandName === 'roll') {
      const max = parseInt(args[0]) || 100;
      const result = Math.floor(Math.random() * max) + 1;
      return message.reply(`🎲 You rolled a **${result}** (1-${max})!`);
    }
    if (commandName === 'uptime') {
      const totalSeconds = (client.uptime / 1000);
      const days = Math.floor(totalSeconds / 86400);
      const hours = Math.floor(totalSeconds / 3600) % 24;
      const minutes = Math.floor(totalSeconds / 60) % 60;
      return message.reply(`⏱️ Bot Uptime: **${days}d ${hours}h ${minutes}m**`);
    }
    if (commandName === 'ticketcreatesetup') return handleTicketCreateSetup(message);
    if (commandName === 'autosetuponetap') return handleAutoSetupOneTap(message);

    // ------------------------------------------
    // INFORMATION COMMANDS
    // ------------------------------------------
    if (commandName === 'botinfo') {
      const embed = new EmbedBuilder().setColor('#2b2d31').setTitle('🤖 Bot Information')
        .addFields(
          { name: 'Servers', value: `${client.guilds.cache.size}`, inline: true },
          { name: 'Users', value: `${client.users.cache.size}`, inline: true },
          { name: 'Node.js', value: process.version, inline: true },
          { name: 'Ping', value: `${Math.round(client.ws.ping)}ms`, inline: true }
        );
      return message.reply({ embeds: [embed] });
    }
    if (commandName === 'channelinfo') {
      const ch = message.mentions.channels.first() || message.channel;
      const embed = new EmbedBuilder().setColor('#2b2d31').setTitle(`📂 Channel: ${ch.name}`)
        .addFields(
          { name: 'ID', value: ch.id, inline: true },
          { name: 'Type', value: ch.type === 0 ? 'Text' : 'Voice', inline: true },
          { name: 'Created', value: `<t:${Math.floor(ch.createdTimestamp / 1000)}:d>`, inline: true }
        );
      return message.reply({ embeds: [embed] });
    }
    if (commandName === 'roleinfo') {
      const role = message.mentions.roles.first();
      if (!role) return message.reply('❌ Please mention a role.');
      const embed = new EmbedBuilder().setColor(role.hexColor).setTitle(`🎨 Role: ${role.name}`)
        .addFields(
          { name: 'ID', value: role.id, inline: true },
          { name: 'Members', value: `${role.members.size}`, inline: true },
          { name: 'Color Hex', value: role.hexColor, inline: true }
        );
      return message.reply({ embeds: [embed] });
    }
    if (commandName === 'emojilist') {
      const emojis = message.guild.emojis.cache.map(e => e.toString()).join(' ');
      if (!emojis) return message.reply('❌ This server has no custom emojis.');
      return message.reply({ content: `**Server Emojis:**\n${emojis.substring(0, 2000)}` });
    }
    if (commandName === 'inrole') {
      const role = message.mentions.roles.first();
      if (!role) return message.reply('❌ Please mention a role.');
      const membersInRole = role.members.map(m => m.user.tag).join('\n');
      if (!membersInRole) return message.reply('❌ No members have this role.');
      return message.reply({ content: `**Members in ${role.name}:**\n\`\`\`${membersInRole.substring(0, 1900)}\`\`\`` });
    }
    if (commandName === 'avatar') return handleAvatar(message, args);
    if (commandName === 'userinfo') return handleUserInfo(message, args);
    if (commandName === 'serverinfo') return handleServerInfo(message);
    if (commandName === 'allmembers') return handleAllMembersCommand(message);
    if (commandName === 'ping') return handlePing(message);

    // ------------------------------------------
    // MODERATION COMMANDS
    // ------------------------------------------
    if (commandName === 'kick') {
      if (!message.member.permissions.has(PermissionsBitField.Flags.KickMembers)) return message.reply('❌ Need Kick Members permission.');
      const target = message.mentions.members.first();
      if (!target) return message.reply('❌ Please mention a user to kick.');
      await target.kick(args.slice(1).join(' ') || 'No reason provided');
      return message.reply(`✅ **${target.user.tag}** has been kicked.`);
    }
    if (commandName === 'ban') {
      if (!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) return message.reply('❌ Need Ban Members permission.');
      const target = message.mentions.members.first();
      if (!target) return message.reply('❌ Please mention a user to ban.');
      await target.ban({ reason: args.slice(1).join(' ') || 'No reason provided' });
      return message.reply(`🔨 **${target.user.tag}** has been banned.`);
    }
    if (commandName === 'timeout') {
      if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) return message.reply('❌ Need Moderate Members permission.');
      const target = message.mentions.members.first();
      const minutes = parseInt(args[1]);
      if (!target || !minutes) return message.reply('❌ Correct usage: `&timeout @user <minutes>`');
      await target.timeout(minutes * 60 * 1000, args.slice(2).join(' ') || 'No reason');
      return message.reply(`⏱️ **${target.user.tag}** timed out for ${minutes} minutes.`);
    }
    if (commandName === 'untimeout') {
      if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) return message.reply('❌ Need Moderate Members permission.');
      const target = message.mentions.members.first();
      if (!target) return message.reply('❌ Please mention a user.');
      await target.timeout(null);
      return message.reply(`✅ Timeout removed for **${target.user.tag}**.`);
    }
    if (commandName === 'lockchannel') {
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) return message.reply('❌ Need Manage Channels permission.');
      await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: false });
      return message.reply('🔒 Channel has been locked.');
    }
    if (commandName === 'clear') return handleClearCommand(message, args);
    if (commandName === 'slowmode') return handleSlowmode(message, args);
    if (commandName === 'removeallroles') return handleRemoveAllRoles(message);
    if (commandName === 'removemembersroles') return handleRemoveMembersRoles(message);

    // ------------------------------------------
    // ANTINUKE COMMANDS
    // ------------------------------------------
    if (['antinuke', 'antiwebhook', 'antispam', 'antiraid'].includes(commandName)) {
      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) return message.reply('❌ Only Administrators can configure Antinuke.');
      const toggle = args[0]?.toLowerCase();
      if (toggle !== 'on' && toggle !== 'off') return message.reply(`❌ Correct usage: \`&${commandName} on/off\``);
      
      antinukeSettings.set(`${message.guild.id}_${commandName}`, toggle === 'on');
      return message.reply(`🛡️ **${commandName.toUpperCase()}** has been turned **${toggle.toUpperCase()}**.`);
    }
    if (commandName === 'whitelist') {
      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) return message.reply('❌ Admin only.');
      const target = message.mentions.users.first();
      if (!target) return message.reply('❌ Mention a user to whitelist.');
      whitelistedUsers.add(target.id);
      return message.reply(`✅ **${target.tag}** is now whitelisted from antinuke protections.`);
    }

  } catch (error) {
    console.error('Error handling command:', error);
    message.reply({ content: '❌ Something went wrong running that command.' }).catch(() => {});
  }
});

// ============================================================
// COMMAND HANDLER FUNCTIONS
// ============================================================
async function handleTicketCreateSetup(message) {
  if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) return message.reply('❌ Need **Manage Server** permission.');
  const ticketSetupChannel = await findOrCreateTextChannel(message.guild, TICKET_SETUP_CHANNEL_NAME, 'Ticket setup.');
  await findOrCreateRole(message.guild, TICKET_MANAGER_ROLE_NAME, { color: 'Yellow' }, 'Ticket setup.');
  const ticketEmoji = await findOrCreateCustomEmoji(message.guild, TICKET_EMOJI_NAME, 'ticket-icon.png');
  await ticketSetupChannel.send(buildTicketSetupMessage(ticketEmoji));
  await message.reply(`✅ Ticket panel posted in ${ticketSetupChannel}!`);
}

async function handleAutoSetupOneTap(message) {
  if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) return message.reply('❌ Need **Manage Server** permission.');
  const category = await findOrCreateCategory(message.guild, ONE_TAP_CATEGORY_NAME, 'One Tap Category.');
  let generator = message.guild.channels.cache.find((c) => c.type === ChannelType.GuildVoice && c.name === JOIN_TO_CREATE_CHANNEL_NAME);
  if (!generator) {
    generator = await message.guild.channels.create({
      name: JOIN_TO_CREATE_CHANNEL_NAME, type: ChannelType.GuildVoice, parent: category.id,
      permissionOverwrites: [{ id: message.guild.roles.everyone.id, allow: [PermissionsBitField.Flags.Connect] }],
    });
  }
  generatorChannels.set(message.guild.id, { categoryId: category.id, generatorChannelId: generator.id });
  await message.reply(`✅ Join-to-Create setup complete! Join ${generator}`);
}

async function handleAllMembersCommand(message) {
  const loadingMsg = await message.reply('⏳ Fetching members...');
  const members = await message.guild.members.fetch();
  const memberList = members.map((m) => `• ${m.user.tag} (${m.id})`);
  const embed = new EmbedBuilder().setTitle(`👥 Member List (${members.size})`).setColor('#00FFFF').setDescription(memberList.slice(0, 30).join('\n') + (memberList.length > 30 ? '\n*...more*' : ''));
  return loadingMsg.edit({ content: null, embeds: [embed] });
}

async function handleClearCommand(message, args) {
  const { channel, member } = message;
  const wantsAll = args[0]?.toLowerCase() === 'all';
  if (wantsAll) {
    if (!member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return sendTempReply(channel, `❌ Need **Manage Messages** permission.`);
    const amount = clampAmount(args[1], CLEAR_MAX_AMOUNT, CLEAR_MAX_AMOUNT);
    await message.delete().catch(() => {});
    const deleted = await channel.bulkDelete(amount, true);
    return sendTempReply(channel, `🧹 Cleared **${deleted.size}** message(s).`);
  }
  const amount = clampAmount(args[0], CLEAR_DEFAULT_AMOUNT, CLEAR_MAX_AMOUNT);
  await message.delete().catch(() => {});
  const recent = await channel.messages.fetch({ limit: 100 });
  const ownMessages = recent.filter((m) => m.author.id === message.author.id).first(amount);
  if (!ownMessages || ownMessages.length === 0) return sendTempReply(channel, `ℹ️ No recent messages to clear.`);
  const deleted = await channel.bulkDelete(ownMessages, true);
  return sendTempReply(channel, `🧹 Cleared **${deleted.size}** of your message(s).`);
}

async function handlePing(message) {
  const sent = await message.reply('🏓 Pinging...');
  await sent.edit(`🏓 Pong! Latency: **${sent.createdTimestamp - message.createdTimestamp}ms** | API: **${Math.round(client.ws.ping)}ms**`);
}

async function handleAvatar(message, args) {
  const target = message.mentions.members.first() || message.member;
  const embed = new EmbedBuilder().setTitle(`${target.user.tag}'s Avatar`).setImage(target.user.displayAvatarURL({ size: 1024, dynamic: true })).setColor('#2b2d31');
  return message.reply({ embeds: [embed] });
}

async function handleUserInfo(message, args) {
  const target = message.mentions.members.first() || message.member;
  const roles = target.roles.cache.filter((r) => r.id !== message.guild.id).map((r) => `${r}`).slice(0, 15);
  const embed = new EmbedBuilder().setTitle(`👤 ${target.user.tag}`).setThumbnail(target.user.displayAvatarURL({ dynamic: true })).setColor('#2b2d31')
    .addFields(
      { name: 'ID', value: target.id, inline: true },
      { name: 'Created', value: `<t:${Math.floor(target.user.createdTimestamp / 1000)}:d>`, inline: true },
      { name: 'Roles', value: roles.length > 0 ? roles.join(', ') : 'None', inline: false }
    );
  return message.reply({ embeds: [embed] });
}

async function handleServerInfo(message) {
  const owner = await message.guild.fetchOwner().catch(() => null);
  const embed = new EmbedBuilder().setTitle(`🏠 ${message.guild.name}`).setColor('#2b2d31').setThumbnail(message.guild.iconURL({ size: 256, dynamic: true }) || null)
    .addFields(
      { name: 'Owner', value: owner ? `${owner}` : 'Unknown', inline: true },
      { name: 'Members', value: `${message.guild.memberCount}`, inline: true }, 
      { name: 'Channels', value: `${message.guild.channels.cache.size}`, inline: true }
    );
  return message.reply({ embeds: [embed] });
}

async function handleSlowmode(message, args) {
  if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) return message.reply('❌ Requires Manage Channels.');
  const seconds = parseInt(args[0], 10) || 0;
  await message.channel.setRateLimitPerUser(seconds);
  return message.reply(`✅ Slowmode set to **${seconds}s**.`);
}

async function handleRemoveAllRoles(message) {
  if (!message.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) return message.reply('❌ Requires **Manage Roles** permission.');
  const statusMsg = await message.reply('⏳ Deleting custom roles...');
  const roles = await message.guild.roles.fetch();
  let deletedCount = 0;
  for (const [, role] of roles) {
    if (role.id !== message.guild.id && !role.managed && message.guild.members.me.roles.highest.position > role.position) {
      await role.delete().catch(() => {});
      deletedCount++;
    }
  }
  return statusMsg.edit(`✅ Deleted **${deletedCount}** roles.`);
}

async function handleRemoveMembersRoles(message) {
  if (!message.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) return message.reply('❌ Requires **Manage Roles** permission.');
  const statusMsg = await message.reply('⏳ Stripping roles from members...');
  const members = await message.guild.members.fetch();
  let updatedCount = 0;
  for (const [, member] of members) {
    const remRoles = member.roles.cache.filter((role) => role.id !== message.guild.id && !role.managed && message.guild.members.me.roles.highest.position > role.position);
    if (remRoles.size > 0) {
      await member.roles.remove(remRoles).catch(() => {});
      updatedCount++;
    }
  }
  return statusMsg.edit(`✅ Stripped roles from **${updatedCount}** members.`);
}

// ============================================================
// ANTINUKE & ANTIWEBHOOK EVENT LISTENERS
// ============================================================
client.on('webhookUpdate', async (channel) => {
  if (!antinukeSettings.get(`${channel.guild.id}_antiwebhook`) && !antinukeSettings.get(`${channel.guild.id}_antinuke`)) return;
  try {
    const auditLogs = await channel.guild.fetchAuditLogs({ limit: 1, type: 50 }); // WEBHOOK_CREATE
    const log = auditLogs.entries.first();
    if (!log) return;
    if (whitelistedUsers.has(log.executor.id) || log.executor.id === client.user.id) return;

    const webhooks = await channel.fetchWebhooks();
    const unauthorizedHooks = webhooks.filter(w => w.owner && w.owner.id === log.executor.id);
    for (const [id, webhook] of unauthorizedHooks) {
      await webhook.delete('Anti-Webhook Protection Triggered');
    }
  } catch (err) { console.error('Antiwebhook Error:', err); }
});

client.on('channelDelete', async (channel) => {
  if (!antinukeSettings.get(`${channel.guild.id}_antinuke`)) return;
  try {
    const auditLogs = await channel.guild.fetchAuditLogs({ limit: 1, type: 12 }); // CHANNEL_DELETE
    const log = auditLogs.entries.first();
    if (!log || whitelistedUsers.has(log.executor.id) || log.executor.id === client.user.id) return;

    await channel.guild.channels.create({
      name: channel.name, type: channel.type, parent: channel.parentId,
      permissionOverwrites: channel.permissionOverwrites.cache.map(overwrite => overwrite),
      reason: 'Antinuke: Restoring unauthorized channel deletion'
    });
  } catch (err) { console.error('Antinuke Channel Delete Error:', err); }
});

// ============================================================
// INTERACTION HANDLER (Buttons, Dropdowns, Modals)
// ============================================================
client.on('interactionCreate', async (interaction) => {
  
  // ------------------------------------------
  // HELP MENU DROPDOWN (With Custom Emoji)
  // ------------------------------------------
  if (interaction.isStringSelectMenu() && interaction.customId.startsWith('help_menu_')) {
    const targetUserId = interaction.customId.split('_')[2];
    if (interaction.user.id !== targetUserId) return interaction.reply({ content: '❌ Only the person who ran `&help` can use this.', ephemeral: true });

    const selected = interaction.values[0];
    if (selected === 'help_home') {
      return interaction.update({ embeds: [getHelpMainEmbed()], components: [new ActionRowBuilder().addComponents(getHelpDropdown(targetUserId))] });
    }

    const embed = new EmbedBuilder().setColor('#2b2d31').setAuthor({ name: '👋 Hello, I\'m Kazuto Kirigaya - 桐ヶ谷和人' });

    if (selected === 'help_general') {
      embed.setTitle('<:general:1538200713216401589> General Commands')
           .addFields(
             { name: `${DOT_EMOJI} \`${PREFIX}say <msg>\``, value: 'Make the bot repeat a message.' },
             { name: `${DOT_EMOJI} \`${PREFIX}8ball <q>\``, value: 'Ask the magic 8-ball a question.' },
             { name: `${DOT_EMOJI} \`${PREFIX}coinflip\``, value: 'Flip a coin (Heads/Tails).' },
             { name: `${DOT_EMOJI} \`${PREFIX}roll [max]\``, value: 'Roll a random number.' },
             { name: `${DOT_EMOJI} \`${PREFIX}uptime\``, value: 'Check how long the bot has been online.' },
             { name: `${DOT_EMOJI} \`${PREFIX}${TICKET_SETUP_COMMAND}\``, value: 'Set up the ticket system.' },
             { name: `${DOT_EMOJI} \`${PREFIX}${AUTOSETUP_ONETAP_COMMAND}\``, value: 'Set up Join-to-Create voice.' },
             { name: `${DOT_EMOJI} \`${PREFIX}panel\``, value: 'Display the temp voice control panel.' }
           );
    } else if (selected === 'help_info') {
      embed.setTitle('<:information:1538200940514119721> Information Commands')
           .addFields(
             { name: `${DOT_EMOJI} \`${PREFIX}botinfo\``, value: 'Display bot statistics.' },
             { name: `${DOT_EMOJI} \`${PREFIX}channelinfo [#ch]\``, value: 'View details about a channel.' },
             { name: `${DOT_EMOJI} \`${PREFIX}roleinfo [@role]\``, value: 'View details about a specific role.' },
             { name: `${DOT_EMOJI} \`${PREFIX}emojilist\``, value: 'List all custom emojis in the server.' },
             { name: `${DOT_EMOJI} \`${PREFIX}inrole [@role]\``, value: 'List all members who have a specific role.' },
             { name: `${DOT_EMOJI} \`${PREFIX}${USERINFO_COMMAND} [@user]\``, value: 'View a user\'s account details.' },
             { name: `${DOT_EMOJI} \`${PREFIX}${SERVERINFO_COMMAND}\``, value: 'Show current server statistics.' },
             { name: `${DOT_EMOJI} \`${PREFIX}${ALL_MEMBERS_COMMAND}\``, value: 'Display a list of all members.' },
             { name: `${DOT_EMOJI} \`${PREFIX}avatar [@user]\``, value: 'Display a user\'s avatar.' }
           );
    } else if (selected === 'help_mod') {
      embed.setTitle('<:moderation:1538201260090720258> Moderation Commands')
           .addFields(
             { name: `${DOT_EMOJI} \`${PREFIX}kick [@user]\``, value: 'Kick a user from the server.' },
             { name: `${DOT_EMOJI} \`${PREFIX}ban [@user]\``, value: 'Ban a user from the server.' },
             { name: `${DOT_EMOJI} \`${PREFIX}timeout [@user] <min>\``, value: 'Mute a user for a set amount of minutes.' },
             { name: `${DOT_EMOJI} \`${PREFIX}untimeout [@user]\``, value: 'Remove a timeout from a user.' },
             { name: `${DOT_EMOJI} \`${PREFIX}lockchannel\``, value: 'Lock the current channel.' },
             { name: `${DOT_EMOJI} \`${PREFIX}${CLEAR_COMMAND} [amount]\``, value: 'Clear recent messages.' },
             { name: `${DOT_EMOJI} \`${PREFIX}${SLOWMODE_COMMAND} <sec>\``, value: 'Adjust channel slowmode limit.' },
             { name: `${DOT_EMOJI} \`${PREFIX}${REMOVE_ALL_ROLES_COMMAND}\``, value: 'Delete all custom roles.' },
             { name: `${DOT_EMOJI} \`${PREFIX}${REMOVE_MEMBERS_ROLES_COMMAND}\``, value: 'Strip all custom roles from members.' }
           );
    } else if (selected === 'help_antinuke') {
      embed.setTitle('<:antinuke:1538201603818127370> Antinuke Commands')
           .addFields(
             { name: `${DOT_EMOJI} \`${PREFIX}antinuke [on/off]\``, value: 'Stop unauthorized channel deletions.' },
             { name: `${DOT_EMOJI} \`${PREFIX}antiwebhook [on/off]\``, value: 'Instantly delete unauthorized webhooks.' },
             { name: `${DOT_EMOJI} \`${PREFIX}antispam [on/off]\``, value: 'Auto-delete 6 messages sent in 5 seconds.' },
             { name: `${DOT_EMOJI} \`${PREFIX}antiraid [on/off]\``, value: 'Toggle strict anti-raid limits.' },
             { name: `${DOT_EMOJI} \`${PREFIX}whitelist [@user]\``, value: 'Exempt a trusted admin from antinuke.' }
           );
    }
    return interaction.update({ embeds: [embed], components: [new ActionRowBuilder().addComponents(getHelpDropdown(targetUserId))] });
  }

  // ------------------------------------------
  // MODAL SUBMISSIONS (Temp Voice Settings)
  // ------------------------------------------
  if (interaction.isModalSubmit()) {
    const voiceChannel = interaction.member?.voice?.channel;
    if (!voiceChannel || !tempChannels.has(voiceChannel.id)) return interaction.reply({ content: '❌ Room no longer active.', ephemeral: true });

    if (interaction.customId === 'modal_tv_rename') {
      const name = interaction.fields.getTextInputValue('input_tv_name');
      await voiceChannel.setName(name);
      return interaction.reply({ content: `✏️ Room renamed to **${name}**`, ephemeral: true });
    }
    if (interaction.customId === 'modal_tv_limit') {
      const limit = parseInt(interaction.fields.getTextInputValue('input_tv_limit'), 10);
      if (isNaN(limit) || limit < 0 || limit > 99) return interaction.reply({ content: '❌ Invalid number.', ephemeral: true });
      await voiceChannel.setUserLimit(limit);
      return interaction.reply({ content: `👥 User limit set to **${limit}**`, ephemeral: true });
    }
    if (interaction.customId === 'modal_tv_allow') {
      const targetId = interaction.fields.getTextInputValue('input_tv_allow_id').trim();
      await voiceChannel.permissionOverwrites.edit(targetId, { Connect: true, ViewChannel: true });
      return interaction.reply({ content: `✅ Access granted to <@${targetId}>.`, ephemeral: true });
    }
    if (interaction.customId === 'modal_tv_deny') {
      const targetId = interaction.fields.getTextInputValue('input_tv_deny_id').trim();
      await voiceChannel.permissionOverwrites.edit(targetId, { Connect: false, ViewChannel: false });
      return interaction.reply({ content: `🚫 Access revoked for <@${targetId}>.`, ephemeral: true });
    }
  }

  // ------------------------------------------
  // BUTTON HANDLERS (Tickets & Temp Voice)
  // ------------------------------------------
  if (!interaction.isButton()) return;
  const { customId, guild, member } = interaction;

  // Tickets
  if (customId === CREATE_TICKET_BUTTON_CUSTOM_ID) {
    const now = Date.now();
    const lastCreated = ticketCreateCooldowns.get(member.id) || 0;
    if (now - lastCreated < 30000) {
      return interaction.reply({ content: `⏱️ Please wait **${Math.ceil((30000 - (now - lastCreated)) / 1000)}s** before creating another ticket.`, ephemeral: true });
    }

    const channelName = `ticket-${member.user.username}`.toLowerCase().replace(/[^a-z0-9]/g, '');
    const existing = guild.channels.cache.find((c) => c.name === channelName || (ticketData.has(c.id) && ticketData.get(c.id).creatorId === member.id));
    if (existing) return interaction.reply({ content: `❌ Close the other ticket (${existing}) and wait 30 sec.`, ephemeral: true });

    const ticketManagerRole = guild.roles.cache.find((r) => r.name === TICKET_MANAGER_ROLE_NAME);
    const permissionOverwrites = [
      { id: guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
      { id: member.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.AttachFiles] },
    ];
    if (ticketManagerRole) permissionOverwrites.push({ id: ticketManagerRole.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.AttachFiles] });

    const ticketChannel = await guild.channels.create({ name: channelName, type: ChannelType.GuildText, permissionOverwrites });
    ticketData.set(ticketChannel.id, { creatorId: member.id, claimedBy: null });
    ticketCreateCooldowns.set(member.id, now);

    const ticketEmbed = new EmbedBuilder().setTitle('🎫 Support Ticket').setDescription(`Welcome <@${member.id}>! State your issue and a ticket manager will be with you shortly.`).setColor('#2b2d31').setImage(TICKET_BANNER_URL);
    const actionRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('close_ticket_btn').setEmoji(CLOSE_TICKET_EMOJI).setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('claim_ticket_btn').setEmoji(CLAIM_TICKET_EMOJI).setStyle(ButtonStyle.Secondary)
    );

    await ticketChannel.send({ content: `<@${member.id}>`, embeds: [ticketEmbed], components: [actionRow] });
    return interaction.reply({ content: `✅ Ticket created: ${ticketChannel}`, ephemeral: true });
  }

  if (customId === 'claim_ticket_btn') {
    const ticketManagerRole = guild.roles.cache.find((r) => r.name === TICKET_MANAGER_ROLE_NAME);
    if (!ticketManagerRole || !member.roles.cache.has(ticketManagerRole.id)) return interaction.reply({ content: '❌ Only Ticket Managers can claim tickets!', ephemeral: true });

    const tData = ticketData.get(interaction.channel.id) || {};
    if (tData.claimedBy) return interaction.reply({ content: `❌ Ticket already claimed by <@${tData.claimedBy}>.`, ephemeral: true });

    tData.claimedBy = member.id;
    ticketData.set(interaction.channel.id, tData);

    await interaction.channel.permissionOverwrites.edit(ticketManagerRole.id, { ViewChannel: false });
    await interaction.channel.permissionOverwrites.edit(member.id, { ViewChannel: true, SendMessages: true, AttachFiles: true });
    if (tData.creatorId) await interaction.channel.permissionOverwrites.edit(tData.creatorId, { ViewChannel: true, SendMessages: true, AttachFiles: true });

    return interaction.reply({ content: `👑 Ticket claimed by <@${member.id}>! Only they and the ticket creator can view this channel now.` });
  }

  if (customId === 'close_ticket_btn') {
    const now = Date.now();
    const lastClosed = ticketCloseCooldowns.get(interaction.user.id) || 0;
    if (now - lastClosed < 30000) return interaction.reply({ content: `⏱️ Please wait **${Math.ceil((30000 - (now - lastClosed)) / 1000)}s** before closing another ticket.`, ephemeral: true });
    
    ticketCloseCooldowns.set(interaction.user.id, now);
    await interaction.reply({ content: '🔒 Closing ticket in 5 seconds...' });
    setTimeout(() => { ticketData.delete(interaction.channel.id); interaction.channel.delete().catch(() => {}); }, 5000);
    return;
  }

  // Temp Voice Interactions
  if (customId.startsWith('tv_')) {
    const voiceChannel = member?.voice?.channel;
    if (!voiceChannel || !tempChannels.has(voiceChannel.id)) return interaction.reply({ content: '❌ Connect to your dynamic voice room first.', ephemeral: true });

    const channelData = tempChannels.get(voiceChannel.id);
    const isOwner = channelData.ownerId === member.id;

    if (customId === 'tv_claim') {
      if (!voiceChannel.members.has(channelData.ownerId)) {
        channelData.ownerId = member.id;
        return interaction.reply({ content: '👑 You are now the owner of this room!', ephemeral: false });
      }
      return interaction.reply({ content: '❌ Current owner is inside the room.', ephemeral: true });
    }

    if (customId === 'tv_info') {
      const ownerMember = await guild.members.fetch(channelData.ownerId).catch(() => null);
      const infoEmbed = new EmbedBuilder().setColor(VC_COLOR).setTitle('ℹ️ Channel Info')
        .addFields(
          { name: '👑 Owner', value: ownerMember ? `<@${ownerMember.id}>` : 'Unknown', inline: true },
          { name: '🔊 Name', value: `\`${voiceChannel.name}\``, inline: true },
          { name: '👥 Capacity', value: voiceChannel.userLimit === 0 ? 'Unlimited' : `${voiceChannel.userLimit}`, inline: true }
        );
      return interaction.reply({ embeds: [infoEmbed], ephemeral: true });
    }

    if (!isOwner) return interaction.reply({ content: '🔒 Only the room owner can manage settings.', ephemeral: true });

    switch (customId) {
      case 'tv_lock': await voiceChannel.permissionOverwrites.edit(guild.roles.everyone, { Connect: false }); return interaction.reply({ content: '🔒 Room locked.', ephemeral: true });
      case 'tv_unlock': await voiceChannel.permissionOverwrites.edit(guild.roles.everyone, { Connect: true }); return interaction.reply({ content: '🔓 Room unlocked.', ephemeral: true });
      case 'tv_hide':
        await voiceChannel.permissionOverwrites.edit(guild.roles.everyone, { ViewChannel: false });
        await voiceChannel.permissionOverwrites.edit(member.id, { ViewChannel: true });
        return interaction.reply({ content: '🙈 Room hidden.', ephemeral: true });
      case 'tv_unhide': await voiceChannel.permissionOverwrites.edit(guild.roles.everyone, { ViewChannel: true }); return interaction.reply({ content: '👁️ Room unhidden.', ephemeral: true });
      case 'tv_rename': {
        const modal = new ModalBuilder().setCustomId('modal_tv_rename').setTitle('Rename Room');
        const input = new TextInputBuilder().setCustomId('input_tv_name').setLabel('New Channel Name').setStyle(TextInputStyle.Short).setRequired(true);
        modal.addComponents(new ActionRowBuilder().addComponents(input));
        return interaction.showModal(modal);
      }
      case 'tv_limit': {
        const modal = new ModalBuilder().setCustomId('modal_tv_limit').setTitle('Set Capacity');
        const input = new TextInputBuilder().setCustomId('input_tv_limit').setLabel('Limit (0 = Unlimited)').setStyle(TextInputStyle.Short).setRequired(true);
        modal.addComponents(new ActionRowBuilder().addComponents(input));
        return interaction.showModal(modal);
      }
      case 'tv_allow': {
        const modal = new ModalBuilder().setCustomId('modal_tv_allow').setTitle('Allow Access');
        const input = new TextInputBuilder().setCustomId('input_tv_allow_id').setLabel('User ID').setStyle(TextInputStyle.Short).setRequired(true);
        modal.addComponents(new ActionRowBuilder().addComponents(input));
        return interaction.showModal(modal);
      }
      case 'tv_deny': {
        const modal = new ModalBuilder().setCustomId('modal_tv_deny').setTitle('Revoke Access');
        const input = new TextInputBuilder().setCustomId('input_tv_deny_id').setLabel('User ID').setStyle(TextInputStyle.Short).setRequired(true);
        modal.addComponents(new ActionRowBuilder().addComponents(input));
        return interaction.showModal(modal);
      }
    }
  }
});

client.login(BOT_TOKEN);